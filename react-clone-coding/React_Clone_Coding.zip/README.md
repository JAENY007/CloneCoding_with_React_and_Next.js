## Clone-Coding Toy PJT

**React, React-router-dom, JavaScript 이용한 클론코딩(1st 퍼블리싱)**  

### April 22nd: 퍼블리싱 일부 사이즈오류 제외하고 완성(?), props 일부 차용

![Example1](../react-clone-coding/public/%ED%81%B4%EB%A1%A0%EC%BD%94%EB%94%A91.png).

![Example2](../react-clone-coding/public/%ED%81%B4%EB%A1%A0%EC%BD%94%EB%94%A92.png).

